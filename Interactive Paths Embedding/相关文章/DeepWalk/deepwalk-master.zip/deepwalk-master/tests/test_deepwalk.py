#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_deepwalk
----------------------------------

Tests for `deepwalk` module.
"""

import unittest

from deepwalk import deepwalk


class TestDeepwalk(unittest.TestCase):

    def setUp(self):
        pass

    def test_something(self):
        pass

    def tearDown(self):
        pass

if __name__ == '__main__':
    unittest.main()